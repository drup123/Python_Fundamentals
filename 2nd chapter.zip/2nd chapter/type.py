s = "45"
b = int(s)
print(type(b))
print(type(s))

a = 5 
print(b%a)

if(a>b):
    print("a is grater")
else:
    print("b is greater")


i = int(input("enter the number"))
u = int(input("enter the number"))
avg = (i + u)/2
print(avg)

sqr = i**2
print(sqr)