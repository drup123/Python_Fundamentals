print("true or false",True or False)
print("true or True",True or True)
print("False or true",False or True)
print("False or false",False or False)